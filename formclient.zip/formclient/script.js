window.onload = function () {
	var client = document.getElementById("client");

	client.addEventListener('change', (event) => {
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
    		data = ""
   			i = 0
    		if (this.readyState == 4 && this.status == 200) {
    			json = JSON.parse(this.responseText)
    			while (i < Object.keys(json).length)
    			{
    				data += Object.keys(json)[i] + ": " + json[Object.keys(json)[i]] + "<br>";
    				i++; 
    			}
     			document.getElementById("data").innerHTML = data;
    		}
  		};

		var select = document.getElementById("client");
		var selectedClient = select.options[select.selectedIndex].value;
  		xhttp.open("POST", "/getclientdata", true);
  		xhttp.send(selectedClient);
  		}
	)
}