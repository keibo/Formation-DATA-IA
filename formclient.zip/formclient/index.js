var http = require('http');
var url = require('url');
var fs = require('fs');
var qs = require('querystring');


var hostname = '127.0.0.1';
var port = 3000;

var datafilename = "data.json";
var scriptfilename = "script.js";

var clients = JSON.parse(fs.readFileSync(datafilename, "utf8"));

var options = "";

var server = http.createServer()

server.on('request', function(req, res) {
	var path = req.url;

    if(path == "/script.js"){
    	res.end(fs.readFileSync(scriptfilename, "utf8"));
    }
    else if(path == "/getclientdata" && req.method == "POST"){
    	var request = '';
		var post;
    
        req.on('data', function (data) {
            request += data;        	
        });

        req.on('end', function () {
            post = qs.parse(request);
            selected = clients.clients.find(client => {return client.name === Object.keys(post)[0]})
		    res.setHeader('Content-Type', 'text/plain');
            res.end(JSON.stringify(selected));
         });
    }
    else {
		res.setHeader('Content-Type', 'text/html');
		res.write("<head>");
		res.write('<title>Formulaires client</title><meta charset="UTF-8"><script type="text/javascript" src="script.js"></script>');
		res.write("</head>");
		res.write("<body>");
		options = buildOptions(clients);
		body =  '<select id="client"><option value="" selected disabled hidden>Choisissez Le Client</option>' + options + '</select>';
		res.write(body);
		res.write('<p id="data">');
		res.write("</p>");
		res.write("</body>");
		res.end();
	}	
});

server.listen(port, hostname);

function buildOptions(clients) {
	i = clients.clients.length;
	options = ""
	while (i > 0){
		i--;
		tmpname = clients.clients[i].name;
		options += '<option value="' + tmpname + '">' + tmpname + '</option>';
	}
	return options;
};